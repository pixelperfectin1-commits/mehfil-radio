import YouTubePlayer from "./youtube-player";

const socials=["Instagram","X","YouTube","Spotify"];

export default function Home(){
 return <main className="relative flex min-h-dvh flex-1 flex-col items-center justify-between overflow-hidden">
  <div aria-hidden className="hero-bg fixed inset-0 -z-20 bg-cover bg-center"/>
  <div aria-hidden className="fixed inset-0 -z-10 bg-gradient-to-b from-black/35 via-black/15 to-black/75"/>
  <div aria-hidden className="grain pointer-events-none fixed inset-0 -z-10 opacity-[.12]"/>
  <div aria-hidden className="vignette pointer-events-none fixed inset-0 -z-10"/>
  <header className="fixed inset-x-0 top-0 z-30 flex items-start justify-between" style={{paddingTop:"var(--safe-top)",paddingLeft:"var(--safe-left)",paddingRight:"var(--safe-right)"}}>
   <div className="text-xs tracking-[.12em] text-white/70">10:42 PM</div>
   <div className="absolute left-1/2 -translate-x-1/2 font-serif text-sm tracking-[.42em] text-white/85">MEHFIL</div>
   <nav className="flex gap-4 text-[10px] uppercase tracking-[.12em] text-white/65">{socials.map(s=><a key={s} href="#" className="hover:text-white">{s}</a>)}</nav>
  </header>
  <section className="relative flex min-h-dvh w-full flex-col items-center justify-center px-5 pb-48 pt-28 text-center">
   <div className="relative z-10"><p className="mb-5 text-[10px] uppercase tracking-[.42em] text-white/60">A 90s Ghazal Radio</p><h1 className="font-serif text-[clamp(70px,13vw,168px)] leading-none font-normal text-[#f4ead7]">मेहफ़िल</h1><p className="mt-6 text-[10px] uppercase tracking-[.35em] text-white/55">90s Hindi · Ghazal · Ishq · Shaam</p><p className="mt-5 font-serif text-sm italic text-white/50">“Thodi si raat, thoda sa ishq, aur ek gaana.”</p></div>
  </section>
  <YouTubePlayer/>
  <div className="pointer-events-none fixed z-20 text-[8px] uppercase tracking-[.28em] text-white/35" style={{bottom:"max(.55rem,env(safe-area-inset-bottom))"}}>Crafted by PixelPerfectIN</div>
 </main>
}