 "use client";
import Script from "next/script";
import {useEffect,useRef,useState} from "react";

declare global{interface Window{YT?:any;onYouTubeIframeAPIReady?:()=>void}}
const PLAYLIST_ID="PLJeNQvgQ4Sl-uomVtOARCoEmMPJUkZH8p";

export default function YouTubePlayer(){
 const mount=useRef<HTMLDivElement>(null),player=useRef<any>(null),timer=useRef<any>(null);
 const [ready,setReady]=useState(false),[playing,setPlaying]=useState(false),[title,setTitle]=useState("MEHFIL RADIO"),[artist,setArtist]=useState("YouTube Playlist"),[current,setCurrent]=useState(0),[duration,setDuration]=useState(0);

 const meta=()=>{if(!player.current)return;const d=player.current.getVideoData?.()||{};setTitle(d.title||"MEHFIL RADIO");setArtist(d.author||"YouTube");setDuration(player.current.getDuration?.()||0)};
 const stop=()=>{if(timer.current){clearInterval(timer.current);timer.current=null}};
 const start=()=>{if(timer.current)return;timer.current=setInterval(()=>{if(player.current){setCurrent(player.current.getCurrentTime?.()||0);setDuration(player.current.getDuration?.()||0)}},500)};
 const create=()=>{if(!window.YT||!mount.current||player.current)return;player.current=new window.YT.Player(mount.current,{width:"1",height:"1",playerVars:{listType:"playlist",list:PLAYLIST_ID,autoplay:0,controls:1,rel:0,modestbranding:1,playsinline:1},events:{onReady:()=>{setReady(true);meta()},onStateChange:(e:any)=>{if(!window.YT)return;const s=window.YT.PlayerState;if(e.data===s.PLAYING){setPlaying(true);meta();start()}else if(e.data===s.PAUSED){setPlaying(false);stop()}else if(e.data===s.ENDED){setPlaying(false);stop();player.current.nextVideo();setTimeout(meta,400)}else if(e.data===s.BUFFERING)meta()}}})};

 useEffect(()=>{if(window.YT)create();else window.onYouTubeIframeAPIReady=create;return()=>{window.onYouTubeIframeAPIReady=undefined;stop()}},[]);
 useEffect(()=>()=>{stop();player.current?.destroy()},[]);
 const toggle=()=>{if(!player.current||!ready)return;playing?player.current.pauseVideo():player.current.playVideo()};
 const next=()=>{if(!player.current||!ready)return;player.current.nextVideo();setTimeout(meta,400)};
 const prev=()=>{if(!player.current||!ready)return;player.current.previousVideo();setTimeout(meta,400)};
 const seek=(e:React.MouseEvent<HTMLDivElement>)=>{if(!player.current||!duration)return;const r=e.currentTarget.getBoundingClientRect(),p=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));player.current.seekTo(p*duration,true);setCurrent(p*duration)};
 const fmt=(v:number)=>{if(!Number.isFinite(v))return"00:00";return `${String(Math.floor(v/60)).padStart(2,"0")}:${String(Math.floor(v%60)).padStart(2,"0")}`};
 const progress=duration?Math.min(100,current/duration*100):0;

 const Vinyl=({mobile=false}:{mobile?:boolean})=><div className={`relative shrink-0 ${mobile?"h-14 w-14":"h-20 w-20"}`}><div className={`vinyl ${playing?"playing":""} h-full w-full rounded-full border border-white/10 bg-[radial-gradient(circle_at_35%_30%,#51463b_0,#211b17_42%,#0e0c0a_78%,#30261f_100%)] shadow-2xl`}><div className="absolute inset-[12%] rounded-full border border-white/10"/><div className="absolute inset-[23%] rounded-full border border-white/10"/><div className="absolute inset-[34%] rounded-full border border-white/10"/><div className="absolute inset-[40%] rounded-full bg-[#eadcc2]"/><div className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#17130f] ring-2 ring-white/40"/></div></div>;
 const Seek=()=> <div className="seek-hit min-w-0 flex-1" onClick={seek} role="slider" aria-label="Seek track" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(progress)} tabIndex={0}><div className="seek-rail"><div className="seek-fill" style={{width:`${progress}%`}}/><div className="seek-knob" style={{left:`${progress}%`}}/></div></div>;

 return <><Script src="https://www.youtube.com/iframe_api" strategy="afterInteractive"/><div ref={mount} className="youtube-shell" aria-hidden="true"/>
  <div className="pointer-events-none fixed inset-x-0 bottom-0 z-30 hidden justify-center sm:flex" style={{paddingLeft:"var(--safe-left)",paddingRight:"var(--safe-right)",paddingBottom:"var(--safe-bottom)"}}>
   <div className="pointer-events-auto flex w-full max-w-xl items-center gap-3 rounded-full p-3 pr-5 glass">
    <Vinyl/><div className="min-w-0 flex-1"><div className="truncate font-serif text-[15px] font-semibold">{title}</div><div className="truncate text-[12.5px] text-white/[.68]">{artist}</div><div className="mt-1 flex items-center gap-2"><Seek/><span className="shrink-0 text-[11px] tabular-nums text-white/50">{fmt(current)} / {fmt(duration)}</span></div></div>
    <div className="flex shrink-0 items-center gap-0.5"><button onClick={prev} className="icon-btn" aria-label="Previous track">◀</button><button onClick={toggle} className="icon-btn play-btn" aria-label={playing?"Pause":"Play"}>{playing?"Ⅱ":"▶"}</button><button onClick={next} className="icon-btn" aria-label="Next track">▶</button></div>
   </div>
  </div>
  <div className="pointer-events-none fixed inset-x-0 bottom-0 z-30 flex justify-center sm:hidden" style={{paddingLeft:"var(--safe-left)",paddingRight:"var(--safe-right)",paddingBottom:"var(--safe-bottom)"}}>
   <div className="pointer-events-auto w-full rounded-[28px] p-4 glass"><div className="flex items-center gap-3"><Vinyl mobile/><div className="min-w-0 flex-1"><div className="truncate font-serif text-sm font-semibold">{title}</div><div className="truncate text-xs text-white/65">{artist}</div></div><button onClick={toggle} className="icon-btn play-btn" aria-label={playing?"Pause":"Play"}>{playing?"Ⅱ":"▶"}</button></div><div className="mt-3"><Seek/><div className="mt-[-2px] flex justify-between text-[10px] tabular-nums text-white/45"><span>{fmt(current)}</span><span>{fmt(duration)}</span></div></div><div className="mt-1 flex justify-center gap-4"><button onClick={prev} className="icon-btn" aria-label="Previous track">◀</button><button onClick={next} className="icon-btn" aria-label="Next track">▶</button></div></div>
  </div>
 </>;
}