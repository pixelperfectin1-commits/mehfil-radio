import type { Metadata, Viewport } from "next";
import { Analytics } from "@vercel/analytics/react";
import { SpeedInsights } from "@vercel/speed-insights/next";
import "./globals.css";

export const metadata: Metadata = { title: "MEHFIL — 90s Ghazal Radio", description: "Late-night ghazal radio." };
export const viewport: Viewport = { width:"device-width", initialScale:1, viewportFit:"cover", themeColor:"#17130F" };

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}<Analytics/><SpeedInsights/></body></html>;
}