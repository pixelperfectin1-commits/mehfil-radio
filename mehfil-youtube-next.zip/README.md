# MEHFIL YouTube Radio
Fresh Next.js App Router version using the YouTube IFrame Player API.
Playlist ID: PLJeNQvgQ4Sl-uomVtOARCoEmMPJUkZH8p

Put `scene-wide.png` and `scene-tall.png` in `public/bg/`.

Run:
npm install
npm run dev
